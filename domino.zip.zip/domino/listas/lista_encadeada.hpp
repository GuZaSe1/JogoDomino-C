#ifndef LISTA_ENCADEADA_HPP
#define LISTA_ENCADEADA_HPP

#include <iostream>
using namespace std;

template <typename T>
struct Nodo {
    T dado;
    Nodo *prox;
};

template <typename T>
struct ListaEncadeada {
    Nodo<T>* inicio;

    void inicializar() {
        inicio = nullptr;
    }

    bool inserirInicio(T item) {
        return inserir(item, 0);
    }

    bool inserirFim(T item) {
        int pos = 0;
        Nodo<T> *aux = inicio;
        while (aux) {
            aux = aux->prox;
            pos++;
        }
        return inserir(item, pos);
    }

    bool inserir(T item, int posicao) {
        Nodo<T>* novo = new Nodo<T>{item, nullptr};

        if (posicao == 0) {
            novo->prox = inicio;
            inicio = novo;
            return true;
        }

        Nodo<T>* aux = inicio;
        for (int i = 0; i < posicao - 1 && aux; i++)
            aux = aux->prox;

        if (!aux) {
            delete novo;
            return false;
        }

        novo->prox = aux->prox;
        aux->prox = novo;
        return true;
    }

    bool removerInicio() {
        return remover(0);
    }

    bool removerFim() {
        if (!inicio) return false;

        int pos = 0;
        Nodo<T>* aux = inicio;
        while (aux->prox) {
            aux = aux->prox;
            pos++;
        }
        return remover(pos);
    }

    bool remover(int posicao) {
        if (!inicio) return false;

        Nodo<T>* aux = inicio;
        if (posicao == 0) {
            inicio = inicio->prox;
            delete aux;
            return true;
        }

        Nodo<T>* anterior = nullptr;
        for (int i = 0; i < posicao && aux; i++) {
            anterior = aux;
            aux = aux->prox;
        }

        if (!aux) return false;

        anterior->prox = aux->prox;
        delete aux;
        return true;
    }

    Nodo<T>* obter(int posicao) {
        Nodo<T>* aux = inicio;
        for (int i = 0; i < posicao && aux; i++)
            aux = aux->prox;
        return aux;
    }

    bool contem(T item) {
        return descobrirIndice(item) != -1;
    }

    int descobrirIndice(T item) {
        Nodo<T>* aux = inicio;
        int pos = 0;
        while (aux) {
            if (aux->dado == item)
                return pos;
            aux = aux->prox;
            pos++;
        }
        return -1;
    }

    void imprimir() {
        cout << "[ ";
        Nodo<T>* aux = inicio;
        while (aux) {
            aux->dado.imprimir(); // Pressupõe que T tenha método imprimir()
            cout << " ";
            aux = aux->prox;
        }
        cout << "]\n";
    }
};

#endif
