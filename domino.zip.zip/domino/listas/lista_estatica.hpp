#ifndef LISTA_ESTATICA_HPP
#define LISTA_ESTATICA_HPP

#include <iostream>
using namespace std;

const int MAX = 50;

template <typename T>
struct ListaEstatica {
    T dados[MAX];
    int tamanho;

    void inicializar() {
        tamanho = 0;
    }

    bool inserirInicio(T item) {
        return inserir(item, 0);
    }

    bool inserirFim(T item) {
        return inserir(item, tamanho);
    }

    bool inserir(T item, int posicao) {
        if (tamanho >= MAX || posicao < 0 || posicao > tamanho)
            return false;

        for (int i = tamanho; i > posicao; i--) {
            dados[i] = dados[i - 1];
        }
        dados[posicao] = item;
        tamanho++;
        return true;
    }

    bool removerInicio() {
        return remover(0);
    }

    bool removerFim() {
        return remover(tamanho - 1);
    }

    bool remover(int posicao) {
        if (posicao < 0 || posicao >= tamanho)
            return false;

        for (int i = posicao; i < tamanho - 1; i++) {
            dados[i] = dados[i + 1];
        }
        tamanho--;
        return true;
    }

    T* obter(int posicao) {
        if (posicao < 0 || posicao >= tamanho)
            return nullptr;
        return &dados[posicao];
    }

    bool contem(T item) {
        return descobrirIndice(item) != -1;
    }

    int descobrirIndice(T item) {
        for (int i = 0; i < tamanho; i++) {
            if (dados[i] == item)
                return i;
        }
        return -1;
    }

    void imprimir() {
        cout << "[ ";
        for (int i = 0; i < tamanho; i++) {
            dados[i].imprimir();  // Pressupõe que T tenha método imprimir()
            cout << " ";
        }
        cout << "]\n";
    }
};

#endif
