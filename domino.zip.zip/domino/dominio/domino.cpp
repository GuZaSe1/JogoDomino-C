#include "domino.hpp"
#include <algorithm>
#include <random>
using namespace std;

// Gera as 28 peças do dominó padrão
void Domino::gerarPecas() {
    monte.inicializar();
    for (int i = 0; i <= 6; i++)
        for (int j = i; j <= 6; j++)
            monte.inserirFim({i, j});
}

// Embaralha o monte de peças
void Domino::embaralharMonte() {
    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(monte.dados, monte.dados + monte.tamanho, g);
}


// Distribui as peças aos jogadores
void Domino::distribuirPecas(int pecasPorJogador) {
    for (int i = 0; i < pecasPorJogador; i++) {
        for (int j = 0; j < jogadores.tamanho; j++) {
            Peca *p = monte.obter(monte.tamanho - 1);
            jogadores.dados[j].adicionarPeca(*p);
            monte.removerFim();
        }
    }
}

// Inicializa o jogo
void Domino::inicializarJogo(int numJogadores, int pecasPorJogador) {
    mesa.inicializar();
    jogadores.inicializar();

    for (int i = 0; i < numJogadores; i++) {
        Jogador novoJogador;
        novoJogador.inicializar("Jogador " + to_string(i + 1));
        jogadores.inserirFim(novoJogador);
    }

    gerarPecas();
    embaralharMonte();
    distribuirPecas(pecasPorJogador);
}

// Log de jogadas
void Domino::logRodada(int rodada, Jogador &jogador, Peca &peca) {
    cout << "[Rodada " << rodada << "] " << jogador.nome << " jogou ";
    peca.imprimir();
    cout << endl;
}

// Execução das rodadas (simplificada)
void Domino::executarRodadas(int numRodadas) {
    for (int rodada = 1; rodada <= numRodadas; rodada++) {
        cout << "\n--- Rodada " << rodada << " ---\n";

        for (int i = 0; i < jogadores.tamanho; i++) {
            Jogador &j = jogadores.dados[i];

            if (j.mao.inicio != nullptr) {
                // Jogador joga a primeira peça disponível
                Peca pecaJogada = j.mao.inicio->dado;
                mesa.inserirFim(pecaJogada);
                logRodada(rodada, j, pecaJogada);
                j.removerPeca(0);
            } else {
                cout << j.nome << " não tem mais peças!\n";
            }
        }
    }
}

// Exibe estado atual do jogo
void Domino::mostrarEstadoAtual() {
    cout << "\n==== Estado atual do jogo ====\n";
    for (int i = 0; i < jogadores.tamanho; i++)
        jogadores.dados[i].imprimirMao();

    cout << "Monte: " << monte.tamanho << " peças restantes\n";

    cout << "Mesa: ";
    mesa.imprimir();
    cout << "===============================\n";
}
