#include "jogador.hpp"
void Jogador::inicializar(string nomeJogador) {
    nome = nomeJogador;
    mao.inicializar();
}
void Jogador::imprimirMao() {
    cout << nome << ": ";
    mao.imprimir();
}
bool Jogador::adicionarPeca(Peca peca) {
    return mao.inserirFim(peca);
}
bool Jogador::removerPeca(int posicao) {
    return mao.remover(posicao);
}
