#ifndef DOMINO_HPP
#define DOMINO_HPP
#include "../listas/lista_estatica.hpp"
#include "../listas/lista_encadeada.hpp"
#include "jogador.hpp"
#include "peca.hpp"
#include <iostream>
#include <random>
using namespace std;

struct Domino {
    ListaEstatica<Peca> monte;
    ListaEncadeada<Peca> mesa;
    ListaEstatica<Jogador> jogadores;

    void inicializarJogo(int numJogadores, int pecasPorJogador);
    void executarRodadas(int numRodadas);
    void mostrarEstadoAtual();

private:
    void gerarPecas();
    void embaralharMonte();
    void distribuirPecas(int pecasPorJogador);
    void logRodada(int rodada, Jogador &jogador, Peca &peca);
};

#endif
