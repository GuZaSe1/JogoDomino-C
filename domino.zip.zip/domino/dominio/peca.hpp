#ifndef PECA_HPP
#define PECA_HPP
#include <iostream>
using namespace std;
struct Peca {
    int ladoA, ladoB;
    Peca(int a = 0, int b = 0) : ladoA(a), ladoB(b) {}
    void imprimir() {
        cout << "[" << ladoA << "|" << ladoB << "]";
    }
    bool operator==(const Peca& outra) const {
        return (ladoA == outra.ladoA && ladoB == outra.ladoB) ||
               (ladoA == outra.ladoB && ladoB == outra.ladoA);
    }
};
#endif