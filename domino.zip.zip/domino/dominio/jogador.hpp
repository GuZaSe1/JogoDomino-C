#ifndef JOGADOR_HPP
#define JOGADOR_HPP
#include <iostream>
#include <string>
#include "../listas/lista_encadeada.hpp"
#include "peca.hpp"
using namespace std;
struct Jogador {
    string nome;
    ListaEncadeada<Peca> mao;
    void inicializar(string nomeJogador);
    void imprimirMao();
    bool adicionarPeca(Peca peca);
    bool removerPeca(int posicao);
};
#endif