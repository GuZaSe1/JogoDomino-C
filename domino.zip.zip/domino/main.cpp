#include <iostream>
#include "listas/lista_estatica.hpp"
#include "listas/lista_encadeada.hpp"
#include "dominio/domino.hpp"
using namespace std;

int main() {
    ListaEstatica<Peca> listaEstatica;
    listaEstatica.inicializar();
    listaEstatica.inserirFim({1, 2});
    listaEstatica.inserirInicio({3, 4});
    listaEstatica.inserir({5, 6}, 1);
    cout << "Lista Estatica: ";
    listaEstatica.imprimir();

    ListaEncadeada<Peca> listaEncadeada;
    listaEncadeada.inicializar();
    listaEncadeada.inserirFim({1, 1});
    listaEncadeada.inserirInicio({2, 2});
    listaEncadeada.inserir({3, 3}, 1);
    cout << "Lista Encadeada: ";
    listaEncadeada.imprimir();

    Domino jogo;

    jogo.inicializarJogo(2, 7);
    jogo.mostrarEstadoAtual();

    jogo.executarRodadas(5);
    jogo.mostrarEstadoAtual();

    return 0;
}

//fazer com que o jogo funcione, com as rodadas e a jogada dos jogadores, o jogo mostre o estado atual do jogo após cada rodada.
//rodar direto no main
//orgazinar codigo com itens que sei como funcionam
//adicionar mais comentarios
//conferir a lista 
//salvar no log
//conferir metricas de avaliacao
//aplicar regras oficiais do domino